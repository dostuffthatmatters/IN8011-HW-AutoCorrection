
/*****************************************************************
* Name: Max Mustermann 02
* Course: MSE Informatik I
* Semester: WS19/20
* Homework 1:N-th partial sum
* File: partial_sum.c
* File type: Template file
*****************************************************************/

#include <stdio.h>
#include <stdlib.h>


/**
* calc_h
*
* This function calculates the n-th partial sum of the harmonic series
*
*
* @param n number of partials
*
* @return n-th partial sum of harmonic series H(n)
*/

double sum;
int n;
double s;

double calc_h(int n){
    //Your code starts here
    sum = 0;
    for (int i = 1; i <= n; i++) {
        sum = sum + 1.0/i;
    }
    return sum;
    //End of your code
}



/**
* calc_n
*
* This function calculates the smallest n, for which the n-th
* partial sum of the harmonic series is larger than or equal to the input h
*
*
* @param h input h
*
* @return smallest n, with H(n) >= h
*/

int calc_n(double h) {
    //Your code starts here
    s = 0;
    n = 0;
    while (1) {
        if (s>=h) {
            break;
        }
        n++;
        s = s + 1.0/n;
        }
    return n;


    //End of your code
}

