
/*****************************************************************
* Name: Max Mustermann 03
* Course: MSE Informatik I
* Semester: WS19/20
* Homework 1:N-th partial sum
* File: partial_sum.c
* File type: Template file
*****************************************************************/

#include <stdio.h>
#include <stdlib.h>


/**
* calc_h
*
* This function calculates the n-th partial sum of the harmonic series
*
*
* @param n number of partials (assume n>=0)
*
* @return n-th partial sum of harmonic series H(n)
*/
double calc_h(int n){
    //Your code starts here
    double H = 0;
    double i = 1;
    while (i < = n);
    {
        H+=1/i;
        i++;
    }
    return H;
    //End of your code
}



/**
* calc_n
*
* This function calculates the smallest n, for which the n-th
* partial sum of the harmonic series is larger than or equal to the input h
*
*
* @param h input h (assume h >=0)
*
* @return smallest n, with H(n) >= h
*/
int calc_n(double h){
    //Your code starts here
    double f = 0.0;
    if (h == 0) {

        return f = 0;
    }

    while (h > 0){

        h=h -1 / f;
        f ++;

    }
    return f -= 1;
    //End of your code
}

