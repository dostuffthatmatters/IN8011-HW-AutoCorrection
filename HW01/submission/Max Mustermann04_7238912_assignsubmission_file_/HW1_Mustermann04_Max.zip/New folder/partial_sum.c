
/*****************************************************************
* Name: Max Mustermann 04
* Course: MSE Informatik I
* Semester: WS19/20
* Homework 1:N-th partial sum
* File: partial_sum.c
* File type: Template file
*****************************************************************/

#include <stdio.h>
#include <stdlib.h>


/**
* calc_h
*
* This function calculates the n-th partial sum of the harmonic series
*
*
* @param n number of partials
*
* @return n-th partial sum of harmonic series H(n)
*/
double calc_h(int n){

    //Your code starts here

    double step_count = 1.0;
    double total_sum = 0;

    while (step_count <= n){

        double sum = 1 / step_count;
        step_count++;
        total_sum = total_sum + sum;
    }
    return total_sum;

    //End of your code

}

/**
* calc_n
*
* This function calculates the smallest n, for which the n-th
* partial sum of the harmonic series is larger than or equal to the input h
*
*
* @param h input h
*
* @return smallest n, with H(n) >= h
*/


int calc_n(double h){

    //Your code starts here

    double n = 1;
    double total_sum = 0;

    while (total_sum < h)
    {
        double sum = 1/ n;
        n += 1;
        total_sum = total_sum + sum;
    }
    return n-1;

    //End of your code
}